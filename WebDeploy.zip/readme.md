## PROOF of CONCEPT ONLY

This code is a proof of concept to show how data can be pulled from M365 Advanced Hunting API to Azure Sentinel.  It is **NOT** prodcution ready code.  Author assumes no responsibility for its use nor implies any warranty.


# Setup

## Function App Config

  1. Install Bicep (see installBicep.ps1 in this repo)
  2. Set parameters in parameters.json file
  3. Run deployApp.ps1
